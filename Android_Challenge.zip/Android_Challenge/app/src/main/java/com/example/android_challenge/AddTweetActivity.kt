package com.example.android_challenge

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddTweetActivity : AppCompatActivity() {
    private lateinit var cancelBtn: Button
    private lateinit var tweetBtn: Button
    private lateinit var tweetEt: EditText
    private lateinit var userImageIv: ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.addtweetactivity)

        cancelBtn = findViewById(R.id.cancelBtn)
        tweetBtn = findViewById(R.id.tweetBtn)
        tweetEt = findViewById(R.id.tweetEt)
        userImageIv = findViewById(R.id.userImageIv)
        userImageIv.setImageResource(R.drawable.prime)

        cancelBtn.setOnClickListener {
            finish()
        }

        tweetBtn.setOnClickListener {
            val tweetText = tweetEt.text.toString()
            if (tweetText.isNotBlank()) {
                // Create an intent to return the tweet data
                val resultIntent = Intent().apply {
                    putExtra("tweetText", tweetText)
                }
                setResult(RESULT_OK, resultIntent)
                finish()
            }else{
                Toast.makeText(this, "Please write something before sending the tweet.", Toast.LENGTH_SHORT).show()
            }
        }

    }
}
