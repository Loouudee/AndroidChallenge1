package com.example.android_challenge

import com.example.android_challenge.Tweet
import java.util.ArrayList

object DataHelper {
    fun loadTweetData(): ArrayList<Tweet> {
        val data = ArrayList<Tweet>()
        data.add(
            Tweet(
                "armin.armode.armedian", "Armin Arlert",
                "RT: Some people consider me a... #bomb",
                9999, R.drawable.armin, CustomDate(2023, 0, 10)
            )
        )
        data.add(
            Tweet(
                "wonderboy", "Zeke Jaeger",
                "HUUUUUUH????",
                1, R.drawable.zeke, CustomDate(2023, 0, 10)
            )
        )
        data.add(
            Tweet(
                "eldian.pride", "Falco Grice",
                "I'm so screwed...",
                13, R.drawable.falco, CustomDate(2023, 0, 10)
            )
        )
        data.add(
            Tweet(
                "rudolph_the_reiner", "Reiner Braun",
                "@jaegermeister awit",
                0, R.drawable.reiner, CustomDate(2023, 0, 10)
            )
        )
        data.add(
            Tweet(
                "jaegermeister", "Eren Jaeger",
                "@rudolph_the_reiner you're just like me, bro",
                454, R.drawable.eren, CustomDate(2023, 0, 10)
            )
        )
        data.add(
            Tweet(
                "eren_simp", "Mikasa Ackerman",
                "Finally get to see Eren!! <3",
                10203, R.drawable.mikasa, CustomDate(2023, 0, 10)
            )
        )
        data.add(
            Tweet(
                "levi", "Levi Ackerman",
                "So dirty here...",
                13, R.drawable.levi, CustomDate(2023, 0, 7)
            )
        )
        data.add(
            Tweet(
                "rudolph_the_reiner", "Reiner Braun",
                "Too much on my mind... #Stressed",
                1, R.drawable.reiner, CustomDate(2023, 0, 8)
            )
        )
        data.add(
            Tweet(
                "eldian.pride", "Falco Grice",
                "SUCK IT, GABI! I won this time!!\n\n***notice me plz*** -.-",
                4, R.drawable.falco, CustomDate(2023, 0, 6)
            )
        )
        data.add(
            Tweet(
                "rudolph_the_reiner", "Reiner Braun",
                "Official broke after the festival :((",
                4, R.drawable.reiner, CustomDate(2023, 0, 4)
            )
        )
        data.add(
            Tweet(
                "eldian.pride", "Falco Grice",
                "Met a nice guy at the nearby hospital!",
                3, R.drawable.falco, CustomDate(2023, 0, 4)
            )
        )
        data.add(
            Tweet(
                "jaegermeister", "Eren Jaeger",
                "Just checked in @ Liberio",
                253, R.drawable.eren, CustomDate(2023, 0, 3)
            )
        )
        data.add(
            Tweet(
                "wonderboy", "Zeke Jaeger",
                "Oh! That's a baseball!",
                3, R.drawable.zeke, CustomDate(2023, 0, 2)
            )
        )
        data.add(
            Tweet(
                "eren_simp", "Mikasa Ackerman",
                "When will Eren notice me?",
                54931, R.drawable.mikasa, CustomDate(2022, 11, 31)
            )
        )
        data.add(
            Tweet(
                "jaegermeister", "Eren Jaeger",
                "Happy New Year, Marley #soon",
                23, R.drawable.eren, CustomDate(2022, 11, 31)
            )
        )
        data.add(
            Tweet(
                "levi", "Levi Ackerman",
                "Need new jeans",
                3423, R.drawable.levi, CustomDate(2022, 10, 16)
            )
        )
        data.add(
            Tweet(
                "armin.armode.armedian", "Armin Arlert",
                "Some people consider me a... #bomb",
                111, R.drawable.armin, CustomDate(2022, 9, 29)
            )
        )
        data.add(
            Tweet(
                "eren_simp", "Mikasa Ackerman",
                "@RandomFan I'm not from Haikyuu",
                68473, R.drawable.mikasa, CustomDate(2022, 7, 5)
            )
        )
        data.add(
            Tweet(
                "armin.armode.armedian", "Armin Arlert",
                "Heading to the beach today!",
                393, R.drawable.armin, CustomDate(2022, 5, 24)
            )
        )
        data.add(
            Tweet(
                "dotpunchman", "Dot Pixis",
                "Just wanted to make a OPM reference",
                1, R.drawable.dot, CustomDate(2005, 4, 5)
            )
        )
        return data
    }
}