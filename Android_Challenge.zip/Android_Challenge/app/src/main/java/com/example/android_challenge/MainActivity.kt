package com.example.android_challenge

import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.floatingactionbutton.FloatingActionButton


import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : AppCompatActivity() {
    private val tweetlist: ArrayList<Tweet> = DataHelper.loadTweetData()
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MyAdapter
    private lateinit var addTweetLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_layout)

        recyclerView = findViewById(R.id.recyclerView)
        adapter = MyAdapter(tweetlist)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        addTweetLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val tweetText = result.data?.getStringExtra("tweetText") ?: return@registerForActivityResult

                // Add new Tweet at the beginning of the list and notify the adapter
                val newTweet = Tweet("DrinkPrimeMaybe", "Prime", tweetText, likes = 0)
                tweetlist.add(0, newTweet)
                adapter.notifyItemInserted(0)
                recyclerView.scrollToPosition(0)
            }
        }

        findViewById<FloatingActionButton>(R.id.addTwtBtn).setOnClickListener {
            val intent = Intent(this, AddTweetActivity::class.java)
            addTweetLauncher.launch(intent)
        }
    }
}


