package com.example.android_challenge

import android.view.ViewGroup
import android.view.LayoutInflater
import androidx.recyclerview.widget.RecyclerView
import com.example.android_challenge.Tweet
import com.example.android_challenge.ViewHolder

class MyAdapter(private val data: ArrayList<Tweet>) : RecyclerView.Adapter<ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.itemrow, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tweet = data[position]
        holder.bind(tweet)
    }

    override fun getItemCount(): Int {
        return data.size
    }
}
